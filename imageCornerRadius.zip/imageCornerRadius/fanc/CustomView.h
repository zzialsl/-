//
//  image.h
//  fanc
//
//  Created by user on 16/9/22.
//  Copyright © 2016年 Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomView : UIView
@property (nonatomic, strong) UIImage *imag;
@end
