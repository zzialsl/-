//
//  DetailController.h
//  fanc
//
//  Created by user on 16/9/23.
//  Copyright © 2016年 Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailController : UIViewController

@end
